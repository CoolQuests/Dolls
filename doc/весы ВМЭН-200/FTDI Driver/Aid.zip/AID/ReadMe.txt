========================================================================
       DYNAMIC LINK LIBRARY : AID
========================================================================


Diese AID-DLL hat der Anwendungs-Assistent f�r Sie erstellt.  

Diese Datei enth�lt eine Zusammenfassung dessen, was Sie in jeder der Dateien
finden, die Ihre AID-Anwendung bilden.

AID.dsp
    Diese Datei (Projektdatei) enth�lt Informationen auf Projektebene und wird zur
    Erstellung eines einzelnen Projekts oder Teilprojekts verwendet. Andere Benutzer k�nnen
    die Projektdatei (.dsp) gemeinsam nutzen, sollten aber die Makefiles lokal exportieren.

AID.cpp
    Dies ist die Hauptquellcodedatei f�r die DLL.

	Diese DLL exportiert keine Symbole, wenn sie erstellt wird. Daher erzeugt sie 
	bei ihrer Erstellung keine .lib-Datei. Wenn dieses Projekt eine Projektabh�ngigkeit
	f�r ein anderes Projekt sein soll, m�ssen Sie entweder Code zum Exportieren einiger 
	Symbole aus der DLL hinzuf�gen, damit eine Exportbibliothek erstellt wird, oder Sie 
	k�nnen das Kontrollk�stchen "Erzeugt keine .LIB" auf der Seite f�r die Linker- 
	Einstellungen f�r dieses Projekt aktivieren. 

/////////////////////////////////////////////////////////////////////////////
Weitere Standarddateien:

StdAfx.h, StdAfx.cpp
    Diese Dateien werden zum Erstellen einer vorkompilierten Header-Datei (PCH) namens
    AID.pch und einer vorkompilierten Typdatei namens StdAfx.obj verwendet.


/////////////////////////////////////////////////////////////////////////////
Weitere Hinweise:

Der Anwendungs-Assistent verwendet "ZU ERLEDIGEN:", um Bereiche des Quellcodes zu
kennzeichnen, die Sie hinzuf�gen oder anpassen sollten.


/////////////////////////////////////////////////////////////////////////////
